package model;

public class Class {

}
